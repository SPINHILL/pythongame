Source files for the article "Pygame --- A Primer". Link TBD
